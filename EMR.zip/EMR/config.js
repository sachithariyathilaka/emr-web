var host = 'http://18.219.8.85';
